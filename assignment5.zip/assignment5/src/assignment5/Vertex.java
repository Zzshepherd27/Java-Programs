package assignment5;

import java.util.Queue;

public class Vertex {
	
	public static final int WHITE = 1; //Sets constants that I never use for some reason
	public static final int GREEN = 2; // >:(
	public static final int BLACK = 3;
	
	private String name; //Name variable for vertex
	private int color; //Color of each node
	private boolean visited; //A true or false value stating whether it has been visited or not
	
	
	public Vertex(String n){
		name = n; //Sets name to n
		color = 0; //Sets our default to 0
		visited = false; //Visited isnt true
	}
	
	public String getName() {
		return name; //Returns name
	}
	
	public int getColor() {
		return color; //Returns color
	}
	
	public void setColor(int c) {
		color = c; //Sets our color to another integer value
	}
	
	public boolean isVisited() {
		return visited; //Returns visited
	}
	
	public void setVisited(boolean v) {
		visited = v; //Sets visited to another true or false value
	}
	
	public String toString() {
		return name; //Returns name
	}
}
