package assignment5;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class GraphAdjacencyList {
	
	private HashMap<String, LinkedList<Vertex> > vertices; //A private hashmap with a vertex key and a list of vertices
	private ArrayList<Vertex> listOfVertices = new ArrayList<Vertex>(); //A private arraylist, with which to hold all vertices in the graph
	
	public GraphAdjacencyList(ArrayList<Vertex> listOfVertices){ //constructor
		vertices = new HashMap<String, LinkedList<Vertex> >(); //Initializes the new hashmap
		for(int i = 0; i < listOfVertices.size(); i++) //Loops through every vertex in the listofvertices
		{
			vertices.put(listOfVertices.get(i).getName(), new LinkedList<Vertex>()); //Sets them inside the hashmap
		}
		this.listOfVertices = listOfVertices; //Sets the list of the object to the list parameter for the constructor
	}
	
	public boolean addEdge(Vertex u, Vertex v) {
		return (vertices.get(u.getName()).add(v) && vertices.get(v.getName()).add(u)); //Adds to each vertices list of neighbors, and in both directions as well
	}
	
	public String toString() {
		String s = "Adjacency list for graph:\n"; //Just the start for this
		for(String key : vertices.keySet()) { //Loops through every key in the vertices map
			s += "Vertex "+key+":"; //Prints each key
			LinkedList<Vertex> adjacentNodes = vertices.get(key); //Creates a linked list of adjacent vertices for each key
			Iterator<Vertex> iterator = adjacentNodes.iterator(); //Creates an iterator to loop through all adjacent vertices
			while (iterator.hasNext()) { //While there are still more adjacent vertices
				Vertex vertex = iterator.next(); //Gets each adjacent vertex
				s+= " ->"+vertex; //Then prints it in the same line as the key
			}
			s+="\n"; //Spacing
		}
		return s; //Returns the string overall
	}
	
	public LinkedList<Vertex> getAdjacencyList(Vertex vertex){
		return vertices.get(vertex.getName()); //Gets the list of vertices adjacent to vertex
	}
	
	public GraphAdjacencyList BreadthFirstSearch(Vertex start) {
		for(int i = 0; i < listOfVertices.size(); i++) //Loops through all the vertices
		{
			listOfVertices.get(i).setColor(1); //Sets the color of each to be 1 (or white)
		}
		GraphAdjacencyList T = new GraphAdjacencyList(listOfVertices); //Makes a new graph of our list of vertices
		LinkedList<Vertex> q = new LinkedList<Vertex>(); //Makes a new linked list of vertices
		q.add(start); //Adds our start parameter since this is where we will start finding adjacent vertices from
		while(q.size() > 0) //While the linked list isnt empty
	    {
			Vertex u = q.remove(); //Gets a value out of the linked list
			LinkedList<Vertex> adjacent = this.getAdjacencyList(u); //Gets all adjacent vertices of u
			for(Vertex v : adjacent) { //Loops through every adjacent vertex
				if(v.getColor() == 1) { //Checks to see if it hasnt been visited yet
					v.setColor(2); //Sets the color to green
					q.add(v); //Adds that vertex to our list to look through
					T.addEdge(u, v); //Adds an edge in both directions
				}
			}
			u.setColor(3); //After looping through and finding each adjacent value, sets u to black, or done with
	    }
		return T; //Returns our new graph
	}
	
	public GraphAdjacencyList DepthFirstSearch(Vertex start) {
		
		Stack<Vertex> s = new Stack<Vertex>(); //creates a stack of verticed
		ArrayList<Vertex> visited = new ArrayList<Vertex>(); //creates an array list of all visited vertices so far
		HashMap<Vertex, Vertex> pre = new HashMap<Vertex,Vertex>(); //creates a hashmap of all predecessors
		for(Vertex v : this.listOfVertices) { //Loops through every vertex
			v.setVisited(false); //Makes them all unvisited
		}
		s.push(start); //Adds start to our stack
		while(!s.isEmpty()) { //While stack isnt empty
			Vertex u = s.pop(); //Get a vertex from our stack
			if(!u.isVisited()) { //Checks if that vertex is visited
				u.setVisited(true); //Sets the vertex to be visited
				visited.add(u); //Adds the vertex to our linked list of visited vertices
				LinkedList<Vertex> adjacent = this.getAdjacencyList(u); //Gets a list of all adjacent vertices to our vertex
				for(Vertex w : adjacent) { //Loops through all adjacent vertices
					if(!w.isVisited()) { //Checks if they were not visited
						s.push(w); //Adds them to our stack if not
						pre.put(w, u); //Puts the edge from w to u inside our predecessor hashmap
					}
				}
			}
		}
		GraphAdjacencyList T = new GraphAdjacencyList(visited); //Makes a graph from every visited vertex
		for(Vertex v: visited) { //Loops through every visited vertex
			if(pre.containsKey(v)) { //Checks if the predecessor map contains the key of each vertex
				Vertex u = pre.get(v); //Gets whatever vertices v is the key for
				T.addEdge(u, v); //Adds an edge officially between u and v in both directions
			}
		}
		return T; //Returns our new graph
	}
}
