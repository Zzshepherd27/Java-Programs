package assignment5;
import java.util.ArrayList;
import java.util.LinkedList;

public class GraphAdjacencyListDriver {

	public static void main(String[] args) {
		
		ArrayList<Vertex> vertices = new ArrayList<Vertex>();
		
		Vertex A = new Vertex("A");
		Vertex B = new Vertex("B");
		Vertex C = new Vertex("C");
		Vertex D = new Vertex("D");
		vertices.add(A);
		vertices.add(B);
		vertices.add(C);
		vertices.add(D);
		
		GraphAdjacencyList graph1 = new GraphAdjacencyList(vertices);	
		System.out.println("Vertices only:\n "+graph1);
		
		graph1.addEdge(A, B);
		graph1.addEdge(B, C);
		graph1.addEdge(B, D);
		graph1.addEdge(C, D);
		
		
		//Test addEdge and getAdjacencyLists
		LinkedList<Vertex> adjacentToA = graph1.getAdjacencyList(A);
		if(adjacentToA.size() == 1  && adjacentToA.get(0) == B)
			System.out.println("Correct only B is adjacent to A");
		else
			System.out.println("Oops only B is adjacent to A");
		
		LinkedList<Vertex> adjacentToB = graph1.getAdjacencyList(B);
		if(adjacentToB.size() == 3 )
			System.out.println("Correct only three nodes are adjacent to B (A, C, and D)");
		else
			System.out.println("Oops adjacent to B is not correct.");
		
		LinkedList<Vertex> adjacencyListB = graph1.getAdjacencyList(B);
		System.out.print("\nVertices adjacent to B: ");
		for(Vertex adjacent: adjacencyListB) {
			System.out.print(adjacent.getName()+" ");
		}
		System.out.println("\n");
		
		System.out.println("Review graph and compare to provide output to see that constructor and addEdge worked");
		System.out.println("\n\nFull graph1:\n"+graph1);
		
		GraphAdjacencyList bfsTree = graph1.BreadthFirstSearch(A);
		System.out.println("BFS Tree:\n"+bfsTree);
		
		GraphAdjacencyList dfsTree = graph1.DepthFirstSearch(A);
		System.out.println("DFS Tree:\n"+dfsTree);
		
		//Second Graph to test
		ArrayList<Vertex> vertices2 = new ArrayList<Vertex>();
		
		Vertex a = new Vertex("a");
		Vertex b = new Vertex("b");
		Vertex c = new Vertex("c");
		Vertex d = new Vertex("d");
		Vertex e = new Vertex("e");
		Vertex f = new Vertex("f");
				
		vertices2.add(a);
		vertices2.add(b);
		vertices2.add(c);
		vertices2.add(d);
		vertices2.add(e);
		vertices2.add(f);
		
		
		GraphAdjacencyList graph2 = new GraphAdjacencyList(vertices2);
				
		graph2.addEdge(a, c);
		graph2.addEdge(a, d);
		graph2.addEdge(c, e);
		graph2.addEdge(c, b);
		graph2.addEdge(d, e);
		graph2.addEdge(e, f);
		graph2.addEdge(b, f);
		
		System.out.println("Graph2:\n"+graph2);
		
		LinkedList<Vertex> adjacencyListC = graph2.getAdjacencyList(c);
		System.out.print("\nVertices adjacent to Vertex c: ");
		for(Vertex adjacent: adjacencyListC) {
			System.out.print(adjacent.getName()+" ");
		}
		System.out.println("\n");
		
		
		//BFS and DFS from Vertex a		
		GraphAdjacencyList bfsTree2 = graph2.BreadthFirstSearch(a);
		System.out.println("\nBFS Tree2 from a:\n"+bfsTree2);
		
		GraphAdjacencyList dfsTree2 = graph2.DepthFirstSearch(a);
		System.out.println("\nDFS Tree2 from a:\n"+dfsTree2);

		//BFS and DFS from Vertex c
		GraphAdjacencyList bfsTree2c = graph2.BreadthFirstSearch(c);
		System.out.println("\nBFS Tree2 from c:\n"+bfsTree2c);
		
		GraphAdjacencyList dfsTree2c = graph2.DepthFirstSearch(c);
		System.out.println("\nDFS Tree2 from c:\n"+dfsTree2c);
		
	}
}
